# My Library

My Library — это простая библиотека для демонстрации создания Python-пакетов.

## Установка

```bash
pip install .