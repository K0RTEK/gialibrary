from .heap import insert_into_heap

__all__ = ['insert_into_heap']